package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Scope("request")
public class BookConsumerController {
	
	@Autowired
	private BookService bookService;
	
	private Logger log=LoggerFactory.getLogger(BookConsumerController.class);
	
	@GetMapping("/get-books/{id}")
	public Book getBookById(@PathVariable("id") int id) {
		log.debug("in getBookById with id= "+id);
		Book book= bookService.getBookById(id);
		log.debug("in getBookById with return value= "+book);
		return book;
	}
}
