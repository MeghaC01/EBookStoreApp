package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository()
public interface BookRepo extends JpaRepository<Book, Integer> {
	
	List<Book> findByTitle(String title);
	List<Book> findByPublisher(String publisher);
	List<Book> findByYear(int year);
}
