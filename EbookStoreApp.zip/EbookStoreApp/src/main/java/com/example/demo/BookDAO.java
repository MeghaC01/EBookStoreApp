package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service(value = "BookDAO")
@Scope(value = "singleton")
public class BookDAO {
	@Autowired
	BookRepo repo;
	
	public List<Book> getallbooks(){
		return repo.findAll();
	}
	
	public Book addbook(Book book) {
		return repo.save(book);
	}
	
	public Book updatebook(Book book) {
		return repo.save(book);
	}

	public Optional<Book> findbookbyid(Integer id) {
		return repo.findById(id);
	}
	
	public void deletebookbyid(Integer id) {
		repo.deleteById(id);
	}
	
	public List<Book> findBookbyName(String name) {
		return repo.findByTitle(name);
	}
	
	public List<Book> findBookbyPublisher(String publisher) {
		return repo.findByPublisher(publisher);
	}
	
	public List<Book> findBookbyYear(int year){
		return repo.findByYear(year);
	}
}
