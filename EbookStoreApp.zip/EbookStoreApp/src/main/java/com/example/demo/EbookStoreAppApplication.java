package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class EbookStoreAppApplication implements CommandLineRunner {

	@Autowired
	BookRepo repo;
	
	public static void main(String[] args) {
		SpringApplication.run(EbookStoreAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		repo.save(new Book(null,"book1","publisher1","123-456-789",256,2018));
		repo.save(new Book(null,"book2","publisher2","123-456-879",257,2019));
		repo.save(new Book(null,"book3","publisher3","123-456-987",258,2010));
		
	}

}
